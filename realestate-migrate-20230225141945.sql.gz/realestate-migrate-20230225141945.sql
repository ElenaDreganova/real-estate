# Миграция MySQL базы данных WordPress
#
# Сформирован: Saturday 25. February 2023 14:19 UTC
# Адрес сайта: localhost
# База данных: `real_estate`
# URL: //real-estate.test
# Path: C:\\xampp\\htdocs\\real-estate.test
# Tables: re_commentmeta, re_comments, re_links, re_options, re_postmeta, re_posts, re_term_relationships, re_term_taxonomy, re_termmeta, re_terms, re_usermeta, re_users
# Table Prefix: re_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, polylang_mo, post, property, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Удалить любую существующую таблицу `re_commentmeta`
#

DROP TABLE IF EXISTS `re_commentmeta`;


#
# Структура таблицы `re_commentmeta`
#

CREATE TABLE `re_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_commentmeta`
#

#
# Конец содержимого данных таблицы `re_commentmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_comments`
#

DROP TABLE IF EXISTS `re_comments`;


#
# Структура таблицы `re_comments`
#

CREATE TABLE `re_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_comments`
#
INSERT INTO `re_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Комментатор WordPress', 'wapuu@wordpress.example', 'https://ru.wordpress.org/', '', '2023-02-10 20:12:50', '2023-02-10 17:12:50', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href="https://ru.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# Конец содержимого данных таблицы `re_comments`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_links`
#

DROP TABLE IF EXISTS `re_links`;


#
# Структура таблицы `re_links`
#

CREATE TABLE `re_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_links`
#

#
# Конец содержимого данных таблицы `re_links`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_options`
#

DROP TABLE IF EXISTS `re_options`;


#
# Структура таблицы `re_options`
#

CREATE TABLE `re_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1691 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_options`
#
INSERT INTO `re_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://real-estate.test', 'yes'),
(2, 'home', 'http://real-estate.test', 'yes'),
(3, 'blogname', 'Real Estate', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'elenadreganova1982@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:21:"polylang/polylang.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'realestate', 'yes'),
(41, 'stylesheet', 'realestate', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '39', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1691601161', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 're_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes') ;
INSERT INTO `re_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:167:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие записи</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:247:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Свежие комментарии</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Архивы</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:154:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Рубрики</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:9:"sidebar-1";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:6:{i:1677337974;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1677345173;a:2:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1677345174;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1677345219;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1677345223;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(124, 'recovery_keys', 'a:0:{}', 'yes'),
(125, 'theme_mods_twentytwentythree', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1676050820;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(128, 'https_detection_errors', 'a:2:{s:23:"ssl_verification_failed";a:1:{i:0;s:38:"Проверка SSL неудачна.";}s:19:"bad_response_source";a:1:{i:0;s:95:"Похоже, что источником ответа не является этот сайт.";}}', 'yes'),
(152, 'can_compress_scripts', '1', 'no'),
(161, 'finished_updating_comment_type', '1', 'yes'),
(162, 'recently_activated', 'a:0:{}', 'yes'),
(171, 'current_theme', 'RealEstate', 'yes'),
(172, 'theme_mods_twentytwentytwo', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1676050891;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}}', 'yes'),
(173, 'theme_switched', '', 'yes'),
(175, 'theme_mods_twentytwentyone', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1676054169;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:9:"sidebar-1";a:0:{}}}}', 'yes'),
(209, 'theme_mods_realestate', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:10:"header_nav";i:6;s:10:"footer_nav";i:6;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(355, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(399, 'recovery_mode_email_last_sent', '1677009158', 'yes'),
(664, 'new_admin_email', 'elenadreganova1982@gmail.com', 'yes'),
(880, 'cities_children', 'a:0:{}', 'yes'),
(1089, 'acf_version', '6.0.7', 'yes'),
(1217, 'cptui_new_install', 'false', 'yes'),
(1251, 'polylang', 'a:15:{s:7:"browser";i:0;s:7:"rewrite";i:1;s:12:"hide_default";i:1;s:10:"force_lang";i:1;s:13:"redirect_lang";i:0;s:13:"media_support";b:1;s:9:"uninstall";i:0;s:4:"sync";a:0:{}s:10:"post_types";a:1:{i:0;s:8:"property";}s:10:"taxonomies";a:2:{i:0;s:6:"cities";i:1;s:8:"features";}s:7:"domains";a:0:{}s:7:"version";s:5:"3.3.1";s:16:"first_activation";i:1676723446;s:12:"default_lang";s:2:"en";s:9:"nav_menus";a:1:{s:10:"realestate";a:2:{s:10:"header_nav";a:3:{s:2:"en";i:6;s:2:"ru";i:6;s:2:"uk";i:6;}s:10:"footer_nav";a:3:{s:2:"en";i:6;s:2:"ru";i:6;s:2:"uk";i:6;}}}}', 'yes'),
(1252, 'polylang_wpml_strings', 'a:0:{}', 'yes'),
(1253, 'widget_polylang', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1261, 'category_children', 'a:0:{}', 'yes'),
(1269, 'pll_dismissed_notices', 'a:1:{i:0;s:6:"wizard";}', 'yes'),
(1279, 'rewrite_rules', 'a:249:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:56:"^(ru|uk)/wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:92:"index.php?lang=$matches[1]&sitemap=$matches[2]&sitemap-subtype=$matches[3]&paged=$matches[4]";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:42:"^(ru|uk)/wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:64:"index.php?lang=$matches[1]&sitemap=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:21:"(ru|uk)/properties/?$";s:45:"index.php?lang=$matches[1]&post_type=property";s:13:"properties/?$";s:36:"index.php?lang=en&post_type=property";s:51:"(ru|uk)/properties/feed/(feed|rdf|rss|rss2|atom)/?$";s:62:"index.php?lang=$matches[1]&post_type=property&feed=$matches[2]";s:43:"properties/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?lang=en&post_type=property&feed=$matches[1]";s:46:"(ru|uk)/properties/(feed|rdf|rss|rss2|atom)/?$";s:62:"index.php?lang=$matches[1]&post_type=property&feed=$matches[2]";s:38:"properties/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?lang=en&post_type=property&feed=$matches[1]";s:38:"(ru|uk)/properties/page/([0-9]{1,})/?$";s:63:"index.php?lang=$matches[1]&post_type=property&paged=$matches[2]";s:30:"properties/page/([0-9]{1,})/?$";s:54:"index.php?lang=en&post_type=property&paged=$matches[1]";s:55:"(ru|uk)/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:50:"(ru|uk)/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:31:"(ru|uk)/category/(.+?)/embed/?$";s:63:"index.php?lang=$matches[1]&category_name=$matches[2]&embed=true";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:43:"(ru|uk)/category/(.+?)/page/?([0-9]{1,})/?$";s:70:"index.php?lang=$matches[1]&category_name=$matches[2]&paged=$matches[3]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:25:"(ru|uk)/category/(.+?)/?$";s:52:"index.php?lang=$matches[1]&category_name=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:52:"(ru|uk)/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:47:"(ru|uk)/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:28:"(ru|uk)/tag/([^/]+)/embed/?$";s:53:"index.php?lang=$matches[1]&tag=$matches[2]&embed=true";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:40:"(ru|uk)/tag/([^/]+)/page/?([0-9]{1,})/?$";s:60:"index.php?lang=$matches[1]&tag=$matches[2]&paged=$matches[3]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:22:"(ru|uk)/tag/([^/]+)/?$";s:42:"index.php?lang=$matches[1]&tag=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:53:"(ru|uk)/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?lang=en&post_format=$matches[1]&feed=$matches[2]";s:48:"(ru|uk)/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?lang=en&post_format=$matches[1]&feed=$matches[2]";s:29:"(ru|uk)/type/([^/]+)/embed/?$";s:61:"index.php?lang=$matches[1]&post_format=$matches[2]&embed=true";s:21:"type/([^/]+)/embed/?$";s:52:"index.php?lang=en&post_format=$matches[1]&embed=true";s:41:"(ru|uk)/type/([^/]+)/page/?([0-9]{1,})/?$";s:68:"index.php?lang=$matches[1]&post_format=$matches[2]&paged=$matches[3]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?lang=en&post_format=$matches[1]&paged=$matches[2]";s:23:"(ru|uk)/type/([^/]+)/?$";s:50:"index.php?lang=$matches[1]&post_format=$matches[2]";s:15:"type/([^/]+)/?$";s:41:"index.php?lang=en&post_format=$matches[1]";s:55:"(ru|uk)/cities/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:62:"index.php?lang=$matches[1]&cities=$matches[2]&feed=$matches[3]";s:47:"cities/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?cities=$matches[1]&feed=$matches[2]";s:50:"(ru|uk)/cities/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:62:"index.php?lang=$matches[1]&cities=$matches[2]&feed=$matches[3]";s:42:"cities/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?cities=$matches[1]&feed=$matches[2]";s:31:"(ru|uk)/cities/([^/]+)/embed/?$";s:56:"index.php?lang=$matches[1]&cities=$matches[2]&embed=true";s:23:"cities/([^/]+)/embed/?$";s:39:"index.php?cities=$matches[1]&embed=true";s:43:"(ru|uk)/cities/([^/]+)/page/?([0-9]{1,})/?$";s:63:"index.php?lang=$matches[1]&cities=$matches[2]&paged=$matches[3]";s:35:"cities/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?cities=$matches[1]&paged=$matches[2]";s:25:"(ru|uk)/cities/([^/]+)/?$";s:45:"index.php?lang=$matches[1]&cities=$matches[2]";s:17:"cities/([^/]+)/?$";s:28:"index.php?cities=$matches[1]";s:57:"(ru|uk)/features/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&features=$matches[2]&feed=$matches[3]";s:49:"features/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?features=$matches[1]&feed=$matches[2]";s:52:"(ru|uk)/features/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&features=$matches[2]&feed=$matches[3]";s:44:"features/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?features=$matches[1]&feed=$matches[2]";s:33:"(ru|uk)/features/([^/]+)/embed/?$";s:58:"index.php?lang=$matches[1]&features=$matches[2]&embed=true";s:25:"features/([^/]+)/embed/?$";s:41:"index.php?features=$matches[1]&embed=true";s:45:"(ru|uk)/features/([^/]+)/page/?([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&features=$matches[2]&paged=$matches[3]";s:37:"features/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?features=$matches[1]&paged=$matches[2]";s:27:"(ru|uk)/features/([^/]+)/?$";s:47:"index.php?lang=$matches[1]&features=$matches[2]";s:19:"features/([^/]+)/?$";s:30:"index.php?features=$matches[1]";s:46:"(ru|uk)/properties/[^/]+/attachment/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:38:"properties/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:56:"(ru|uk)/properties/[^/]+/attachment/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:48:"properties/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:76:"(ru|uk)/properties/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:68:"properties/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:71:"(ru|uk)/properties/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:63:"properties/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:71:"(ru|uk)/properties/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:63:"properties/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:52:"(ru|uk)/properties/[^/]+/attachment/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:44:"properties/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:35:"(ru|uk)/properties/([^/]+)/embed/?$";s:58:"index.php?lang=$matches[1]&property=$matches[2]&embed=true";s:27:"properties/([^/]+)/embed/?$";s:41:"index.php?property=$matches[1]&embed=true";s:39:"(ru|uk)/properties/([^/]+)/trackback/?$";s:52:"index.php?lang=$matches[1]&property=$matches[2]&tb=1";s:31:"properties/([^/]+)/trackback/?$";s:35:"index.php?property=$matches[1]&tb=1";s:59:"(ru|uk)/properties/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&property=$matches[2]&feed=$matches[3]";s:51:"properties/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?property=$matches[1]&feed=$matches[2]";s:54:"(ru|uk)/properties/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&property=$matches[2]&feed=$matches[3]";s:46:"properties/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?property=$matches[1]&feed=$matches[2]";s:47:"(ru|uk)/properties/([^/]+)/page/?([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&property=$matches[2]&paged=$matches[3]";s:39:"properties/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?property=$matches[1]&paged=$matches[2]";s:54:"(ru|uk)/properties/([^/]+)/comment-page-([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&property=$matches[2]&cpage=$matches[3]";s:46:"properties/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?property=$matches[1]&cpage=$matches[2]";s:43:"(ru|uk)/properties/([^/]+)(?:/([0-9]+))?/?$";s:64:"index.php?lang=$matches[1]&property=$matches[2]&page=$matches[3]";s:35:"properties/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?property=$matches[1]&page=$matches[2]";s:35:"(ru|uk)/properties/[^/]+/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:27:"properties/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"(ru|uk)/properties/[^/]+/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:37:"properties/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"(ru|uk)/properties/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:57:"properties/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"(ru|uk)/properties/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:52:"properties/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"(ru|uk)/properties/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:52:"properties/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"(ru|uk)/properties/[^/]+/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:33:"properties/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:40:"(ru|uk)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?lang=$matches[1]&&feed=$matches[2]";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:35:"index.php?lang=en&&feed=$matches[1]";s:35:"(ru|uk)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?lang=$matches[1]&&feed=$matches[2]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:35:"index.php?lang=en&&feed=$matches[1]";s:16:"(ru|uk)/embed/?$";s:38:"index.php?lang=$matches[1]&&embed=true";s:8:"embed/?$";s:29:"index.php?lang=en&&embed=true";s:28:"(ru|uk)/page/?([0-9]{1,})/?$";s:45:"index.php?lang=$matches[1]&&paged=$matches[2]";s:20:"page/?([0-9]{1,})/?$";s:36:"index.php?lang=en&&paged=$matches[1]";s:35:"(ru|uk)/comment-page-([0-9]{1,})/?$";s:56:"index.php?lang=$matches[1]&&page_id=39&cpage=$matches[2]";s:27:"comment-page-([0-9]{1,})/?$";s:47:"index.php?lang=en&&page_id=39&cpage=$matches[1]";s:10:"(ru|uk)/?$";s:26:"index.php?lang=$matches[1]";s:49:"(ru|uk)/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?lang=en&&feed=$matches[1]&withcomments=1";s:44:"(ru|uk)/comments/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?lang=en&&feed=$matches[1]&withcomments=1";s:25:"(ru|uk)/comments/embed/?$";s:38:"index.php?lang=$matches[1]&&embed=true";s:17:"comments/embed/?$";s:29:"index.php?lang=en&&embed=true";s:52:"(ru|uk)/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?lang=en&s=$matches[1]&feed=$matches[2]";s:47:"(ru|uk)/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?lang=en&s=$matches[1]&feed=$matches[2]";s:28:"(ru|uk)/search/(.+)/embed/?$";s:51:"index.php?lang=$matches[1]&s=$matches[2]&embed=true";s:20:"search/(.+)/embed/?$";s:42:"index.php?lang=en&s=$matches[1]&embed=true";s:40:"(ru|uk)/search/(.+)/page/?([0-9]{1,})/?$";s:58:"index.php?lang=$matches[1]&s=$matches[2]&paged=$matches[3]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:49:"index.php?lang=en&s=$matches[1]&paged=$matches[2]";s:22:"(ru|uk)/search/(.+)/?$";s:40:"index.php?lang=$matches[1]&s=$matches[2]";s:14:"search/(.+)/?$";s:31:"index.php?lang=en&s=$matches[1]";s:55:"(ru|uk)/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?lang=en&author_name=$matches[1]&feed=$matches[2]";s:50:"(ru|uk)/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:58:"index.php?lang=en&author_name=$matches[1]&feed=$matches[2]";s:31:"(ru|uk)/author/([^/]+)/embed/?$";s:61:"index.php?lang=$matches[1]&author_name=$matches[2]&embed=true";s:23:"author/([^/]+)/embed/?$";s:52:"index.php?lang=en&author_name=$matches[1]&embed=true";s:43:"(ru|uk)/author/([^/]+)/page/?([0-9]{1,})/?$";s:68:"index.php?lang=$matches[1]&author_name=$matches[2]&paged=$matches[3]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?lang=en&author_name=$matches[1]&paged=$matches[2]";s:25:"(ru|uk)/author/([^/]+)/?$";s:50:"index.php?lang=$matches[1]&author_name=$matches[2]";s:17:"author/([^/]+)/?$";s:41:"index.php?lang=en&author_name=$matches[1]";s:77:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:72:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:53:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:91:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&embed=true";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:65:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:98:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&paged=$matches[5]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:47:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:80:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:64:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:59:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:40:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/embed/?$";s:75:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&embed=true";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:52:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:82:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&paged=$matches[4]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:34:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/?$";s:64:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:51:"(ru|uk)/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:46:"(ru|uk)/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:27:"(ru|uk)/([0-9]{4})/embed/?$";s:54:"index.php?lang=$matches[1]&year=$matches[2]&embed=true";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:39:"(ru|uk)/([0-9]{4})/page/?([0-9]{1,})/?$";s:61:"index.php?lang=$matches[1]&year=$matches[2]&paged=$matches[3]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:21:"(ru|uk)/([0-9]{4})/?$";s:43:"index.php?lang=$matches[1]&year=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:66:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:76:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:96:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:91:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:91:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:72:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:61:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:108:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:65:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:102:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&tb=1";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:85:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:114:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&feed=$matches[6]";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:80:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:114:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&feed=$matches[6]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:73:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:115:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&paged=$matches[6]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:80:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:115:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&cpage=$matches[6]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:69:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:114:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&page=$matches[6]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:55:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:65:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:85:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:80:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:80:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:61:"(ru|uk)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:72:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:98:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&cpage=$matches[5]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:59:"(ru|uk)/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:82:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:46:"(ru|uk)/([0-9]{4})/comment-page-([0-9]{1,})/?$";s:61:"index.php?lang=$matches[1]&year=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:35:"(ru|uk)/.?.+?/attachment/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"(ru|uk)/.?.+?/attachment/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"(ru|uk)/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"(ru|uk)/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"(ru|uk)/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"(ru|uk)/.?.+?/attachment/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"(ru|uk)/(.?.+?)/embed/?$";s:58:"index.php?lang=$matches[1]&pagename=$matches[2]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:28:"(ru|uk)/(.?.+?)/trackback/?$";s:52:"index.php?lang=$matches[1]&pagename=$matches[2]&tb=1";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:48:"(ru|uk)/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:43:"(ru|uk)/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:36:"(ru|uk)/(.?.+?)/page/?([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&pagename=$matches[2]&paged=$matches[3]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:43:"(ru|uk)/(.?.+?)/comment-page-([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&pagename=$matches[2]&cpage=$matches[3]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:32:"(ru|uk)/(.?.+?)(?:/([0-9]+))?/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&page=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(1640, 'taxonomy_21', 'a:1:{s:15:"class_term_meta";s:8:"test  22";}', 'yes'),
(1690, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1677334785;}', 'no') ;

#
# Конец содержимого данных таблицы `re_options`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_postmeta`
#

DROP TABLE IF EXISTS `re_postmeta`;


#
# Структура таблицы `re_postmeta`
#

CREATE TABLE `re_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=466 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_postmeta`
#
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(37, 2, '_wp_trash_meta_status', 'publish'),
(38, 2, '_wp_trash_meta_time', '1676225471'),
(39, 2, '_wp_desired_post_slug', 'sample-page'),
(42, 19, '_edit_lock', '1676724255:1'),
(70, 25, '_menu_item_type', 'custom'),
(71, 25, '_menu_item_menu_item_parent', '0'),
(72, 25, '_menu_item_object_id', '25'),
(73, 25, '_menu_item_object', 'custom'),
(74, 25, '_menu_item_target', ''),
(75, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(76, 25, '_menu_item_xfn', ''),
(77, 25, '_menu_item_url', 'http://real-estate.test/'),
(106, 29, '_menu_item_type', 'post_type'),
(107, 29, '_menu_item_menu_item_parent', '0'),
(108, 29, '_menu_item_object_id', '19'),
(109, 29, '_menu_item_object', 'page'),
(110, 29, '_menu_item_target', ''),
(111, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(112, 29, '_menu_item_xfn', ''),
(113, 29, '_menu_item_url', ''),
(114, 29, '_menu_item_orphaned', '1676234824'),
(115, 30, '_menu_item_type', 'post_type'),
(116, 30, '_menu_item_menu_item_parent', '0'),
(117, 30, '_menu_item_object_id', '19'),
(118, 30, '_menu_item_object', 'page'),
(119, 30, '_menu_item_target', ''),
(120, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(121, 30, '_menu_item_xfn', ''),
(122, 30, '_menu_item_url', ''),
(123, 30, '_menu_item_orphaned', '1676234831'),
(124, 31, '_menu_item_type', 'post_type'),
(125, 31, '_menu_item_menu_item_parent', '0'),
(126, 31, '_menu_item_object_id', '19'),
(127, 31, '_menu_item_object', 'page'),
(128, 31, '_menu_item_target', ''),
(129, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(130, 31, '_menu_item_xfn', ''),
(131, 31, '_menu_item_url', ''),
(132, 31, '_menu_item_orphaned', '1676234838'),
(160, 25, '_wp_old_date', '2023-02-12'),
(162, 35, '_menu_item_type', 'custom'),
(163, 35, '_menu_item_menu_item_parent', '0'),
(164, 35, '_menu_item_object_id', '35'),
(165, 35, '_menu_item_object', 'custom'),
(166, 35, '_menu_item_target', ''),
(167, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(168, 35, '_menu_item_xfn', ''),
(169, 35, '_menu_item_url', '#'),
(171, 36, '_menu_item_type', 'custom'),
(172, 36, '_menu_item_menu_item_parent', '0'),
(173, 36, '_menu_item_object_id', '36'),
(174, 36, '_menu_item_object', 'custom'),
(175, 36, '_menu_item_target', ''),
(176, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(177, 36, '_menu_item_xfn', ''),
(178, 36, '_menu_item_url', '#'),
(180, 37, '_menu_item_type', 'custom'),
(181, 37, '_menu_item_menu_item_parent', '0'),
(182, 37, '_menu_item_object_id', '37'),
(183, 37, '_menu_item_object', 'custom'),
(184, 37, '_menu_item_target', ''),
(185, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(186, 37, '_menu_item_xfn', ''),
(187, 37, '_menu_item_url', '#'),
(189, 38, '_menu_item_type', 'custom'),
(190, 38, '_menu_item_menu_item_parent', '0'),
(191, 38, '_menu_item_object_id', '38'),
(192, 38, '_menu_item_object', 'custom'),
(193, 38, '_menu_item_target', ''),
(194, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(195, 38, '_menu_item_xfn', ''),
(196, 38, '_menu_item_url', '#'),
(198, 39, '_edit_lock', '1676908844:1'),
(199, 39, '_wp_page_template', 'template-homepage.php'),
(200, 50, '_edit_last', '1'),
(201, 50, '_edit_lock', '1677010855:1'),
(202, 51, '_wp_attached_file', '2023/02/1.webp'),
(203, 51, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:401;s:4:"file";s:14:"2023/02/1.webp";s:8:"filesize";i:35644;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(204, 50, '_thumbnail_id', '51'),
(205, 52, '_edit_last', '1'),
(206, 52, '_edit_lock', '1676585540:1'),
(207, 53, '_wp_attached_file', '2023/02/2.webp'),
(208, 53, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:14:"2023/02/2.webp";s:8:"filesize";i:91472;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(209, 54, '_edit_last', '1'),
(210, 54, '_edit_lock', '1676585602:1'),
(211, 55, '_wp_attached_file', '2023/02/3.webp'),
(212, 55, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:14:"2023/02/3.webp";s:8:"filesize";i:55734;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(213, 54, '_thumbnail_id', '55'),
(214, 57, '_edit_last', '1'),
(215, 57, '_edit_lock', '1676585387:1'),
(216, 58, '_wp_attached_file', '2023/02/4.webp'),
(217, 58, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:343;s:4:"file";s:14:"2023/02/4.webp";s:8:"filesize";i:35256;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(218, 57, '_thumbnail_id', '58'),
(219, 59, '_edit_last', '1'),
(220, 59, '_edit_lock', '1677015849:1'),
(221, 60, '_wp_attached_file', '2023/02/5.webp'),
(222, 60, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:450;s:4:"file";s:14:"2023/02/5.webp";s:8:"filesize";i:109938;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(223, 59, '_thumbnail_id', '60') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(224, 61, '_edit_last', '1'),
(225, 61, '_edit_lock', '1676585104:1'),
(226, 62, '_wp_attached_file', '2023/02/6.webp'),
(227, 62, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:14:"2023/02/6.webp";s:8:"filesize";i:45338;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(228, 61, '_thumbnail_id', '62'),
(229, 63, '_edit_last', '1'),
(230, 63, '_edit_lock', '1676584943:1'),
(231, 64, '_wp_attached_file', '2023/02/7.webp'),
(232, 64, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:416;s:4:"file";s:14:"2023/02/7.webp";s:8:"filesize";i:62798;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(233, 63, '_thumbnail_id', '64'),
(234, 65, '_wp_attached_file', '2023/02/8.webp'),
(235, 65, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:358;s:4:"file";s:14:"2023/02/8.webp";s:8:"filesize";i:52670;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(236, 52, '_thumbnail_id', '65'),
(237, 67, '_edit_last', '1'),
(238, 67, '_edit_lock', '1676584882:1'),
(239, 68, '_wp_attached_file', '2023/02/8-1.webp'),
(240, 68, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:358;s:4:"file";s:16:"2023/02/8-1.webp";s:8:"filesize";i:52670;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(241, 67, '_thumbnail_id', '68'),
(242, 69, '_edit_last', '1'),
(243, 69, '_edit_lock', '1676584659:1'),
(244, 70, '_wp_attached_file', '2023/02/9.webp'),
(245, 70, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:14:"2023/02/9.webp";s:8:"filesize";i:90250;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(246, 69, '_thumbnail_id', '70'),
(247, 71, '_edit_last', '1'),
(248, 71, '_edit_lock', '1676825241:1'),
(249, 72, '_wp_attached_file', '2023/02/10.webp'),
(250, 72, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:600;s:6:"height";i:400;s:4:"file";s:15:"2023/02/10.webp";s:8:"filesize";i:73056;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(251, 71, '_thumbnail_id', '72'),
(252, 73, '_edit_last', '1'),
(253, 73, '_edit_lock', '1676743677:1'),
(254, 73, '_thumbnail_id', '53'),
(255, 3, '_edit_lock', '1676724184:1'),
(257, 19, '_edit_last', '1'),
(258, 19, 'price', '20000'),
(259, 78, '_edit_last', '1'),
(260, 78, '_edit_lock', '1677009245:1'),
(261, 73, 'price', '300000'),
(262, 73, '_price', 'field_63ee9a18d21bf'),
(263, 73, 'area', '120'),
(264, 73, '_area', 'field_63ee9ac2d21c0'),
(265, 71, 'price', '200000'),
(266, 71, '_price', 'field_63ee9a18d21bf'),
(267, 71, 'area', '100'),
(268, 71, '_area', 'field_63ee9ac2d21c0'),
(269, 69, 'price', '250000'),
(270, 69, '_price', 'field_63ee9a18d21bf'),
(271, 69, 'area', '90'),
(272, 69, '_area', 'field_63ee9ac2d21c0'),
(273, 67, 'price', '500000'),
(274, 67, '_price', 'field_63ee9a18d21bf'),
(275, 67, 'area', '200'),
(276, 67, '_area', 'field_63ee9ac2d21c0'),
(277, 63, 'price', '1200000'),
(278, 63, '_price', 'field_63ee9a18d21bf'),
(279, 63, 'area', '300'),
(280, 63, '_area', 'field_63ee9ac2d21c0'),
(281, 61, 'price', '400000'),
(282, 61, '_price', 'field_63ee9a18d21bf'),
(283, 61, 'area', '280'),
(284, 61, '_area', 'field_63ee9ac2d21c0'),
(285, 59, 'price', '50000'),
(286, 59, '_price', 'field_63ee9a18d21bf'),
(287, 59, 'area', '20'),
(288, 59, '_area', 'field_63ee9ac2d21c0'),
(289, 57, 'price', '100000'),
(290, 57, '_price', 'field_63ee9a18d21bf'),
(291, 57, 'area', '40'),
(292, 57, '_area', 'field_63ee9ac2d21c0'),
(293, 52, 'price', '600000'),
(294, 52, '_price', 'field_63ee9a18d21bf'),
(295, 52, 'area', '190'),
(296, 52, '_area', 'field_63ee9ac2d21c0'),
(297, 54, 'price', '650000'),
(298, 54, '_price', 'field_63ee9a18d21bf'),
(299, 54, 'area', '260'),
(300, 54, '_area', 'field_63ee9ac2d21c0'),
(301, 50, 'price', '2000000'),
(302, 50, '_price', 'field_63ee9a18d21bf'),
(303, 50, 'area', '600'),
(304, 50, '_area', 'field_63ee9ac2d21c0'),
(305, 81, '_edit_last', '1'),
(306, 81, '_edit_lock', '1676909283:1'),
(307, 84, '_pll_strings_translations', 'a:0:{}'),
(308, 85, '_pll_strings_translations', 'a:0:{}'),
(309, 86, '_pll_strings_translations', 'a:0:{}'),
(310, 88, '_edit_lock', '1676724202:1'),
(311, 89, 'price', '300000'),
(312, 89, 'area', '120'),
(313, 89, '_thumbnail_id', '53'),
(314, 90, 'price', '300000'),
(315, 90, 'area', '120'),
(316, 90, '_thumbnail_id', '53'),
(317, 91, 'price', '300000'),
(318, 91, 'area', '120'),
(319, 91, '_thumbnail_id', '53'),
(320, 92, 'price', '300000'),
(321, 92, 'area', '120'),
(322, 92, '_thumbnail_id', '53'),
(323, 92, '_edit_last', '1'),
(324, 92, '_price', 'field_63ee9a18d21bf') ;
INSERT INTO `re_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(325, 92, '_area', 'field_63ee9ac2d21c0'),
(326, 92, '_edit_lock', '1676827028:1'),
(327, 93, 'price', '300000'),
(328, 93, 'area', '120'),
(329, 93, '_thumbnail_id', '53'),
(330, 93, '_edit_last', '1'),
(331, 93, '_price', 'field_63ee9a18d21bf'),
(332, 93, '_area', 'field_63ee9ac2d21c0'),
(333, 93, '_edit_lock', '1676743652:1'),
(334, 94, '_menu_item_type', 'custom'),
(335, 94, '_menu_item_menu_item_parent', '0'),
(336, 94, '_menu_item_object_id', '94'),
(337, 94, '_menu_item_object', 'custom'),
(338, 94, '_menu_item_target', ''),
(339, 94, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(340, 94, '_menu_item_xfn', ''),
(341, 94, '_menu_item_url', '#pll_switcher'),
(343, 25, '_wp_old_date', '2023-02-13'),
(344, 35, '_wp_old_date', '2023-02-13'),
(345, 37, '_wp_old_date', '2023-02-13'),
(346, 38, '_wp_old_date', '2023-02-13'),
(347, 36, '_wp_old_date', '2023-02-13'),
(348, 94, '_pll_menu_item', 'a:6:{s:22:"hide_if_no_translation";i:0;s:12:"hide_current";i:0;s:10:"force_home";i:0;s:10:"show_flags";i:0;s:10:"show_names";i:1;s:8:"dropdown";i:0;}'),
(349, 95, 'price', '200000'),
(350, 95, 'area', '100'),
(351, 95, '_thumbnail_id', '72'),
(352, 95, '_edit_last', '1'),
(353, 95, '_price', 'field_63ee9a18d21bf'),
(354, 95, '_area', 'field_63ee9ac2d21c0'),
(355, 95, '_edit_lock', '1676733250:1'),
(356, 96, 'price', '200000'),
(357, 96, 'area', '100'),
(358, 96, '_thumbnail_id', '72'),
(359, 96, '_edit_last', '1'),
(360, 96, '_price', 'field_63ee9a18d21bf'),
(361, 96, '_area', 'field_63ee9ac2d21c0'),
(362, 96, '_edit_lock', '1677017789:1'),
(363, 97, '_edit_last', '1'),
(364, 97, '_edit_lock', '1676742304:1'),
(365, 97, '_wp_trash_meta_status', 'publish'),
(366, 97, '_wp_trash_meta_time', '1676742717'),
(367, 97, '_wp_desired_post_slug', 'group_63f10dcb95629'),
(368, 98, '_wp_trash_meta_status', 'publish'),
(369, 98, '_wp_trash_meta_time', '1676742718'),
(370, 98, '_wp_desired_post_slug', 'field_63f10dce3d831'),
(371, 100, '_wp_attached_file', '2023/02/bed.png'),
(372, 100, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:35;s:6:"height";i:20;s:4:"file";s:15:"2023/02/bed.png";s:8:"filesize";i:253;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(373, 96, 'bed', '0'),
(374, 96, '_bed', 'field_63f11054c8a24'),
(381, 102, '_edit_lock', '1676825362:1'),
(382, 105, '_edit_lock', '1676825436:1'),
(383, 106, '_edit_lock', '1676825513:1'),
(384, 107, '_edit_lock', '1676825524:1'),
(385, 125, '_edit_lock', '1676826989:1'),
(386, 1, '_edit_lock', '1676827172:1'),
(408, 165, '_edit_lock', '1676907528:1'),
(430, 172, '_edit_lock', '1676908817:1'),
(431, 173, '_edit_lock', '1676908870:1'),
(465, 201, '_edit_lock', '1677018605:1') ;

#
# Конец содержимого данных таблицы `re_postmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_posts`
#

DROP TABLE IF EXISTS `re_posts`;


#
# Структура таблицы `re_posts`
#

CREATE TABLE `re_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_posts`
#
INSERT INTO `re_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-02-10 20:12:50', '2023-02-10 17:12:50', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'draft', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2023-02-14 18:03:51', '2023-02-14 15:03:51', '', 0, 'http://real-estate.test/?p=1', 0, 'post', '', 1),
(2, 1, '2023-02-10 20:12:50', '2023-02-10 17:12:50', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href="http://real-estate.test/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2023-02-12 21:11:11', '2023-02-12 18:11:11', '', 0, 'http://real-estate.test/?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-02-10 20:12:50', '2023-02-10 17:12:50', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Наш адрес сайта: http://real-estate.test.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email ("хеш") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность "Запомнить меня", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2023-02-14 18:02:35', '2023-02-14 15:02:35', '', 0, 'http://real-estate.test/?page_id=3', 0, 'page', '', 0),
(6, 1, '2023-02-10 20:35:06', '2023-02-10 17:35:06', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentythree', '', '', '2023-02-10 20:35:06', '2023-02-10 17:35:06', '', 0, 'http://real-estate.test/2023/02/10/wp-global-styles-twentytwentythree/', 0, 'wp_global_styles', '', 0),
(7, 1, '2023-02-10 20:40:31', '2023-02-10 17:40:31', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentytwo', '', '', '2023-02-10 20:40:31', '2023-02-10 17:40:31', '', 0, 'http://real-estate.test/2023/02/10/wp-global-styles-twentytwentytwo/', 0, 'wp_global_styles', '', 0),
(15, 1, '2023-02-12 21:10:31', '2023-02-12 18:10:31', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2023-02-12 21:10:31', '2023-02-12 18:10:31', '', 1, 'http://real-estate.test/?p=15', 0, 'revision', '', 0),
(16, 1, '2023-02-12 21:11:06', '2023-02-12 18:11:06', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Наш адрес сайта: http://real-estate.test.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email ("хеш") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность "Запомнить меня", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2023-02-12 21:11:06', '2023-02-12 18:11:06', '', 3, 'http://real-estate.test/?p=16', 0, 'revision', '', 0),
(17, 1, '2023-02-12 21:11:11', '2023-02-12 18:11:11', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href="http://real-estate.test/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2023-02-12 21:11:11', '2023-02-12 18:11:11', '', 2, 'http://real-estate.test/?p=17', 0, 'revision', '', 0),
(19, 1, '2023-02-12 21:50:10', '2023-02-12 18:50:10', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"align":"wide","style":{"typography":{"fontSize":"48px","lineHeight":"1.1"}}} -->\n<h2 class="alignwide" id="we-re-a-studio-in-berlin-with-an-international-practice-in-architecture-urban-planning-and-interior-design-we-believe-in-sharing-knowledge-and-promoting-dialogue-to-increase-the-creative-potential-of-collaboration" style="font-size:48px;line-height:1.1">Мы - студия в Берлине с международной практикой в ​​области архитектуры, городского планирования и дизайна интерьеров. Мы верим в обмен знаниями и продвижение диалога для увеличения творческого потенциала сотрудничества.</h2>\n<!-- /wp:heading -->', 'Пример страницы', '', 'publish', 'closed', 'closed', '', 'hi', '', '', '2023-02-16 23:49:18', '2023-02-16 20:49:18', '', 0, 'http://real-estate.test/?page_id=19', 0, 'page', '', 0),
(20, 1, '2023-02-12 21:50:10', '2023-02-12 18:50:10', '', 'hi', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2023-02-12 21:50:10', '2023-02-12 18:50:10', '', 19, 'http://real-estate.test/?p=20', 0, 'revision', '', 0),
(24, 1, '2023-02-12 22:53:23', '2023-02-12 19:53:23', '', 'Пример страницы', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2023-02-12 22:53:23', '2023-02-12 19:53:23', '', 19, 'http://real-estate.test/?p=24', 0, 'revision', '', 0),
(25, 1, '2023-02-18 16:06:44', '2023-02-12 20:26:44', '', 'Home', '', 'publish', 'closed', 'closed', '', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f', '', '', '2023-02-18 16:06:44', '2023-02-18 13:06:44', '', 0, 'http://real-estate.test/?p=25', 1, 'nav_menu_item', '', 0),
(29, 1, '2023-02-12 23:47:04', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-02-12 23:47:04', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?p=29', 1, 'nav_menu_item', '', 0),
(30, 1, '2023-02-12 23:47:11', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-02-12 23:47:11', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?p=30', 1, 'nav_menu_item', '', 0),
(31, 1, '2023-02-12 23:47:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2023-02-12 23:47:17', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?p=31', 1, 'nav_menu_item', '', 0),
(35, 1, '2023-02-18 16:06:44', '2023-02-12 21:11:07', '', 'Properties', '', 'publish', 'closed', 'closed', '', 'properties', '', '', '2023-02-18 16:06:44', '2023-02-18 13:06:44', '', 0, 'http://real-estate.test/?p=35', 2, 'nav_menu_item', '', 0),
(36, 1, '2023-02-18 16:06:45', '2023-02-12 21:11:07', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2023-02-18 16:06:45', '2023-02-18 13:06:45', '', 0, 'http://real-estate.test/?p=36', 5, 'nav_menu_item', '', 0),
(37, 1, '2023-02-18 16:06:45', '2023-02-12 21:11:07', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2023-02-18 16:06:45', '2023-02-18 13:06:45', '', 0, 'http://real-estate.test/?p=37', 3, 'nav_menu_item', '', 0),
(38, 1, '2023-02-18 16:06:45', '2023-02-12 21:24:01', '', 'FAQ', '', 'publish', 'closed', 'closed', '', 'faq', '', '', '2023-02-18 16:06:45', '2023-02-18 13:06:45', '', 0, 'http://real-estate.test/?p=38', 4, 'nav_menu_item', '', 0),
(39, 1, '2023-02-13 00:53:58', '2023-02-12 21:53:58', '', 'Главная страница', '', 'publish', 'closed', 'closed', '', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0', '', '', '2023-02-13 01:07:11', '2023-02-12 22:07:11', '', 0, 'http://real-estate.test/?page_id=39', 0, 'page', '', 0),
(40, 1, '2023-02-13 00:53:58', '2023-02-12 21:53:58', '', 'Главная страница', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2023-02-13 00:53:58', '2023-02-12 21:53:58', '', 39, 'http://real-estate.test/?p=40', 0, 'revision', '', 0),
(50, 1, '2023-02-15 01:30:04', '2023-02-14 22:30:04', '', 'Первый', '', 'publish', 'closed', 'closed', '', '%d0%bf%d0%b5%d1%80%d0%b2%d1%8b%d0%b9', '', '', '2023-02-17 01:16:26', '2023-02-16 22:16:26', '', 0, 'http://real-estate.test/?post_type=property&#038;p=50', 0, 'property', '', 0),
(51, 1, '2023-02-15 01:29:47', '2023-02-14 22:29:47', '', '1', '', 'inherit', 'open', 'closed', '', '1', '', '', '2023-02-15 01:29:47', '2023-02-14 22:29:47', '', 50, 'http://real-estate.test/wp-content/uploads/2023/02/1.webp', 0, 'attachment', 'image/webp', 0),
(52, 1, '2023-02-15 01:33:24', '2023-02-14 22:33:24', '', 'Второй', '', 'publish', 'closed', 'closed', '', '%d0%b2%d1%82%d0%be%d1%80%d0%be%d0%b9', '', '', '2023-02-17 01:14:35', '2023-02-16 22:14:35', '', 0, 'http://real-estate.test/?post_type=property&#038;p=52', 0, 'property', '', 0),
(53, 1, '2023-02-15 01:33:10', '2023-02-14 22:33:10', '', '2', '', 'inherit', 'open', 'closed', '', '2', '', '', '2023-02-15 01:33:10', '2023-02-14 22:33:10', '', 52, 'http://real-estate.test/wp-content/uploads/2023/02/2.webp', 0, 'attachment', 'image/webp', 0),
(54, 1, '2023-02-15 01:36:23', '2023-02-14 22:36:23', '&nbsp;\r\n\r\n&nbsp;', 'Третий', '', 'publish', 'closed', 'closed', '', '%d1%82%d1%80%d0%b5%d1%82%d0%b8%d0%b9', '', '', '2023-02-17 01:15:38', '2023-02-16 22:15:38', '', 0, 'http://real-estate.test/?post_type=property&#038;p=54', 0, 'property', '', 0),
(55, 1, '2023-02-15 01:36:01', '2023-02-14 22:36:01', '', '3', '', 'inherit', 'open', 'closed', '', '3', '', '', '2023-02-15 01:36:01', '2023-02-14 22:36:01', '', 54, 'http://real-estate.test/wp-content/uploads/2023/02/3.webp', 0, 'attachment', 'image/webp', 0),
(57, 1, '2023-02-15 01:42:09', '2023-02-14 22:42:09', '', 'Четвертый', '', 'publish', 'closed', 'closed', '', '%d1%87%d0%b5%d1%82%d0%b2%d0%b5%d1%80%d1%82%d1%8b%d0%b9', '', '', '2023-02-17 01:08:00', '2023-02-16 22:08:00', '', 0, 'http://real-estate.test/?post_type=property&#038;p=57', 0, 'property', '', 0),
(58, 1, '2023-02-15 01:40:24', '2023-02-14 22:40:24', '', '4', '', 'inherit', 'open', 'closed', '', '4', '', '', '2023-02-15 01:40:24', '2023-02-14 22:40:24', '', 57, 'http://real-estate.test/wp-content/uploads/2023/02/4.webp', 0, 'attachment', 'image/webp', 0),
(59, 1, '2023-02-15 01:43:09', '2023-02-14 22:43:09', '', 'Пятый', '', 'publish', 'closed', 'closed', '', '%d0%bf%d1%8f%d1%82%d1%8b%d0%b9', '', '', '2023-02-17 01:06:10', '2023-02-16 22:06:10', '', 0, 'http://real-estate.test/?post_type=property&#038;p=59', 0, 'property', '', 0),
(60, 1, '2023-02-15 01:42:56', '2023-02-14 22:42:56', '', '5', '', 'inherit', 'open', 'closed', '', '5', '', '', '2023-02-15 01:42:56', '2023-02-14 22:42:56', '', 59, 'http://real-estate.test/wp-content/uploads/2023/02/5.webp', 0, 'attachment', 'image/webp', 0),
(61, 1, '2023-02-15 01:43:54', '2023-02-14 22:43:54', '', 'Шестой', '', 'publish', 'closed', 'closed', '', '%d1%88%d0%b5%d1%81%d1%82%d0%be%d0%b9', '', '', '2023-02-17 01:07:14', '2023-02-16 22:07:14', '', 0, 'http://real-estate.test/?post_type=property&#038;p=61', 0, 'property', '', 0),
(62, 1, '2023-02-15 01:43:45', '2023-02-14 22:43:45', '', '6', '', 'inherit', 'open', 'closed', '', '6', '', '', '2023-02-15 01:43:45', '2023-02-14 22:43:45', '', 61, 'http://real-estate.test/wp-content/uploads/2023/02/6.webp', 0, 'attachment', 'image/webp', 0),
(63, 1, '2023-02-15 01:44:41', '2023-02-14 22:44:41', '', 'Седьмой', '', 'publish', 'closed', 'closed', '', '%d1%81%d0%b5%d0%b4%d1%8c%d0%bc%d0%be%d0%b9', '', '', '2023-02-17 01:04:40', '2023-02-16 22:04:40', '', 0, 'http://real-estate.test/?post_type=property&#038;p=63', 0, 'property', '', 0),
(64, 1, '2023-02-15 01:44:33', '2023-02-14 22:44:33', '', '7', '', 'inherit', 'open', 'closed', '', '7', '', '', '2023-02-15 01:44:33', '2023-02-14 22:44:33', '', 63, 'http://real-estate.test/wp-content/uploads/2023/02/7.webp', 0, 'attachment', 'image/webp', 0),
(65, 1, '2023-02-15 02:06:24', '2023-02-14 23:06:24', '', '8', '', 'inherit', 'open', 'closed', '', '8', '', '', '2023-02-15 02:06:24', '2023-02-14 23:06:24', '', 52, 'http://real-estate.test/wp-content/uploads/2023/02/8.webp', 0, 'attachment', 'image/webp', 0),
(66, 1, '2023-02-17 01:14:24', '2023-02-16 22:14:24', '', 'Второй', '', 'inherit', 'closed', 'closed', '', '52-autosave-v1', '', '', '2023-02-17 01:14:24', '2023-02-16 22:14:24', '', 52, 'http://real-estate.test/?p=66', 0, 'revision', '', 0),
(67, 1, '2023-02-15 02:21:58', '2023-02-14 23:21:58', '', 'Восьмой', '', 'publish', 'closed', 'closed', '', '%d0%b2%d0%be%d1%81%d1%8c%d0%bc%d0%be%d0%b9', '', '', '2023-02-17 01:03:37', '2023-02-16 22:03:37', '', 0, 'http://real-estate.test/?post_type=property&#038;p=67', 0, 'property', '', 0),
(68, 1, '2023-02-15 02:21:46', '2023-02-14 23:21:46', '', '8', '', 'inherit', 'open', 'closed', '', '8-2', '', '', '2023-02-15 02:21:46', '2023-02-14 23:21:46', '', 67, 'http://real-estate.test/wp-content/uploads/2023/02/8-1.webp', 0, 'attachment', 'image/webp', 0),
(69, 1, '2023-02-15 02:22:44', '2023-02-14 23:22:44', '', 'Девятый', '', 'publish', 'closed', 'closed', '', '%d0%b4%d0%b5%d0%b2%d1%8f%d1%82%d1%8b%d0%b9', '', '', '2023-02-17 00:59:49', '2023-02-16 21:59:49', '', 0, 'http://real-estate.test/?post_type=property&#038;p=69', 0, 'property', '', 0),
(70, 1, '2023-02-15 02:22:36', '2023-02-14 23:22:36', '', '9', '', 'inherit', 'open', 'closed', '', '9', '', '', '2023-02-15 02:22:36', '2023-02-14 23:22:36', '', 69, 'http://real-estate.test/wp-content/uploads/2023/02/9.webp', 0, 'attachment', 'image/webp', 0),
(71, 1, '2023-02-15 02:23:49', '2023-02-14 23:23:49', '', 'Tenth', '', 'publish', 'closed', 'closed', '', '%d0%b4%d0%b5%d1%81%d1%8f%d1%82%d1%8b%d0%b9', '', '', '2023-02-18 18:17:08', '2023-02-18 15:17:08', '', 0, 'http://real-estate.test/?post_type=property&#038;p=71', 0, 'property', '', 0),
(72, 1, '2023-02-15 02:23:41', '2023-02-14 23:23:41', '', '10', '', 'inherit', 'open', 'closed', '', '10', '', '', '2023-02-15 02:23:41', '2023-02-14 23:23:41', '', 71, 'http://real-estate.test/wp-content/uploads/2023/02/10.webp', 0, 'attachment', 'image/webp', 0),
(73, 1, '2023-02-15 02:24:26', '2023-02-14 23:24:26', '', 'Одиннадцатый', '', 'publish', 'closed', 'closed', '', '%d0%be%d0%b4%d0%b8%d0%bd%d0%bd%d0%b0%d0%b4%d1%86%d0%b0%d1%82%d1%8b%d0%b9', '', '', '2023-02-17 00:57:15', '2023-02-16 21:57:15', '', 0, 'http://real-estate.test/?post_type=property&#038;p=73', 0, 'property', '', 0),
(76, 1, '2023-02-16 23:31:08', '2023-02-16 20:31:08', '<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {"align":"wide","style":{"typography":{"fontSize":"48px","lineHeight":"1.1"}}} -->\n<h2 class="alignwide" id="we-re-a-studio-in-berlin-with-an-international-practice-in-architecture-urban-planning-and-interior-design-we-believe-in-sharing-knowledge-and-promoting-dialogue-to-increase-the-creative-potential-of-collaboration" style="font-size:48px;line-height:1.1">Мы - студия в Берлине с международной практикой в ​​области архитектуры, городского планирования и дизайна интерьеров. Мы верим в обмен знаниями и продвижение диалога для увеличения творческого потенциала сотрудничества.</h2>\n<!-- /wp:heading -->', 'Пример страницы', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2023-02-16 23:31:08', '2023-02-16 20:31:08', '', 19, 'http://real-estate.test/?p=76', 0, 'revision', '', 0),
(78, 1, '2023-02-17 00:09:21', '2023-02-16 21:09:21', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:8:"property";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Properties Custom Field', 'properties-custom-field', 'publish', 'closed', 'closed', '', 'group_63ee9a161ea76', '', '', '2023-02-21 23:53:52', '2023-02-21 20:53:52', '', 0, 'http://real-estate.test/?post_type=acf-field-group&#038;p=78', 0, 'acf-field-group', '', 0),
(79, 1, '2023-02-17 00:09:21', '2023-02-16 21:09:21', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:0;s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Price', 'price', 'publish', 'closed', 'closed', '', 'field_63ee9a18d21bf', '', '', '2023-02-21 23:53:52', '2023-02-21 20:53:52', '', 78, 'http://real-estate.test/?post_type=acf-field&#038;p=79', 0, 'acf-field', '', 0),
(80, 1, '2023-02-17 00:09:21', '2023-02-16 21:09:21', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";i:0;s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Area', 'area', 'publish', 'closed', 'closed', '', 'field_63ee9ac2d21c0', '', '', '2023-02-21 23:53:52', '2023-02-21 20:53:52', '', 78, 'http://real-estate.test/?post_type=acf-field&#038;p=80', 1, 'acf-field', '', 0),
(81, 1, '2023-02-17 01:36:58', '2023-02-16 22:36:58', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:8:"taxonomy";s:8:"operator";s:2:"==";s:5:"value";s:3:"all";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Taxonomy', 'taxonomy', 'publish', 'closed', 'closed', '', 'group_63eeafae8c9b4', '', '', '2023-02-22 00:37:20', '2023-02-21 21:37:20', '', 0, 'http://real-estate.test/?post_type=acf-field-group&#038;p=81', 0, 'acf-field-group', '', 0),
(82, 1, '2023-02-17 01:36:58', '2023-02-16 22:36:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'image', 'image', 'publish', 'closed', 'closed', '', 'field_63eeafb069a76', '', '', '2023-02-22 00:37:20', '2023-02-21 21:37:20', '', 81, 'http://real-estate.test/?post_type=acf-field&#038;p=82', 0, 'acf-field', '', 0),
(84, 1, '2023-02-18 15:34:59', '2023-02-18 12:34:59', '', 'polylang_mo_7', '', 'private', 'closed', 'closed', '', 'polylang_mo_7', '', '', '2023-02-18 15:34:59', '2023-02-18 12:34:59', '', 0, 'http://real-estate.test/?post_type=polylang_mo&p=84', 0, 'polylang_mo', '', 0),
(85, 1, '2023-02-18 15:35:00', '2023-02-18 12:35:00', '', 'polylang_mo_10', '', 'private', 'closed', 'closed', '', 'polylang_mo_10', '', '', '2023-02-18 15:35:00', '2023-02-18 12:35:00', '', 0, 'http://real-estate.test/?post_type=polylang_mo&p=85', 0, 'polylang_mo', '', 0),
(86, 1, '2023-02-18 15:35:03', '2023-02-18 12:35:03', '', 'polylang_mo_14', '', 'private', 'closed', 'closed', '', 'polylang_mo_14', '', '', '2023-02-18 15:35:03', '2023-02-18 12:35:03', '', 0, 'http://real-estate.test/?post_type=polylang_mo&p=86', 0, 'polylang_mo', '', 0),
(87, 1, '2023-02-18 15:38:36', '2023-02-18 12:38:36', '', 'Главная страница - Русский', '', 'publish', 'closed', 'closed', '', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0-%d1%80%d1%83%d1%81%d1%81%d0%ba%d0%b8%d0%b9', '', '', '2023-02-18 15:38:36', '2023-02-18 12:38:36', '', 0, 'http://real-estate.test/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0-%d1%80%d1%83%d1%81%d1%81%d0%ba%d0%b8%d0%b9/', 0, 'page', '', 0),
(88, 1, '2023-02-18 15:38:37', '2023-02-18 12:38:37', '', 'Главная страница - Українська', '', 'publish', 'closed', 'closed', '', '%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0-%d1%83%d0%ba%d1%80%d0%b0%d1%97%d0%bd%d1%81%d1%8c%d0%ba%d0%b0', '', '', '2023-02-18 15:38:37', '2023-02-18 12:38:37', '', 0, 'http://real-estate.test/%d0%b3%d0%bb%d0%b0%d0%b2%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0-%d1%83%d0%ba%d1%80%d0%b0%d1%97%d0%bd%d1%81%d1%8c%d0%ba%d0%b0/', 0, 'page', '', 0),
(89, 1, '2023-02-18 16:00:04', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-18 16:00:04', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=89', 0, 'property', '', 0),
(90, 1, '2023-02-18 16:00:24', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-18 16:00:24', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=90', 0, 'property', '', 0),
(91, 1, '2023-02-18 16:00:41', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-18 16:00:41', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=91', 0, 'property', '', 0),
(92, 1, '2023-02-18 16:02:11', '2023-02-18 13:02:11', '', 'Eleventh', '', 'publish', 'closed', 'closed', '', 'eleventh', '', '', '2023-02-18 16:02:24', '2023-02-18 13:02:24', '', 0, 'http://real-estate.test/?post_type=property&#038;p=92', 0, 'property', '', 0),
(93, 1, '2023-02-18 16:03:06', '2023-02-18 13:03:06', '', 'Одинадцятий', '', 'publish', 'closed', 'closed', '', '%d0%be%d0%b4%d0%b8%d0%bd%d0%b0%d0%b4%d1%86%d1%8f%d1%82%d0%b8%d0%b9', '', '', '2023-02-18 16:03:14', '2023-02-18 13:03:14', '', 0, 'http://real-estate.test/?post_type=property&#038;p=93', 0, 'property', '', 0),
(94, 1, '2023-02-18 16:06:45', '2023-02-18 13:06:45', '', 'Языки', '', 'publish', 'closed', 'closed', '', '%d1%8f%d0%b7%d1%8b%d0%ba%d0%b8', '', '', '2023-02-18 16:06:45', '2023-02-18 13:06:45', '', 0, 'http://real-estate.test/?p=94', 6, 'nav_menu_item', '', 0),
(95, 1, '2023-02-18 18:16:24', '2023-02-18 15:16:24', '', 'Десятий', '', 'publish', 'closed', 'closed', '', '%d0%b4%d0%b5%d1%81%d1%8f%d1%82%d0%b8%d0%b9', '', '', '2023-02-18 18:16:24', '2023-02-18 15:16:24', '', 0, 'http://real-estate.test/?post_type=property&#038;p=95', 0, 'property', '', 0),
(96, 1, '2023-02-18 18:18:14', '2023-02-18 15:18:14', '', 'Десятый', '', 'publish', 'closed', 'closed', '', '%d0%b4%d0%b5%d1%81%d1%8f%d1%82%d1%8b%d0%b9-2', '', '', '2023-02-18 21:22:59', '2023-02-18 18:22:59', '', 0, 'http://real-estate.test/?post_type=property&#038;p=96', 0, 'property', '', 0),
(97, 1, '2023-02-18 20:45:42', '2023-02-18 17:45:42', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:10:"attachment";s:8:"operator";s:2:"==";s:5:"value";s:9:"image/png";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Icon', 'icon', 'trash', 'closed', 'closed', '', 'group_63f10dcb95629__trashed', '', '', '2023-02-18 20:51:57', '2023-02-18 17:51:57', '', 0, 'http://real-estate.test/?post_type=acf-field-group&#038;p=97', 0, 'acf-field-group', '', 0),
(98, 1, '2023-02-18 20:45:42', '2023-02-18 17:45:42', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Bed', 'bed', 'trash', 'closed', 'closed', '', 'field_63f10dce3d831__trashed', '', '', '2023-02-18 20:51:58', '2023-02-18 17:51:58', '', 97, 'http://real-estate.test/?post_type=acf-field&#038;p=98', 0, 'acf-field', '', 0),
(100, 1, '2023-02-18 20:53:47', '2023-02-18 17:53:47', '', 'bed', '3', 'inherit', 'open', 'closed', '', 'bed', '', '', '2023-02-18 20:55:13', '2023-02-18 17:55:13', '', 96, 'http://real-estate.test/wp-content/uploads/2023/02/bed.png', 0, 'attachment', 'image/png', 0),
(102, 1, '2023-02-19 19:51:34', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:51:34', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?page_id=102', 0, 'page', '', 0),
(103, 1, '2023-02-19 19:52:10', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:52:10', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=103', 0, 'property', '', 0),
(104, 1, '2023-02-19 19:52:33', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:52:33', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=104', 0, 'property', '', 0),
(105, 1, '2023-02-19 19:52:45', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-02-19 19:52:45', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?p=105', 0, 'post', '', 0),
(106, 1, '2023-02-19 19:54:04', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:54:04', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?page_id=106', 0, 'page', '', 0),
(107, 1, '2023-02-19 19:54:17', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:54:17', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?page_id=107', 0, 'page', '', 0),
(108, 1, '2023-02-19 19:54:40', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:54:40', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=108', 0, 'property', '', 0),
(109, 1, '2023-02-19 19:54:50', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:54:50', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=109', 0, 'property', '', 0),
(110, 1, '2023-02-19 19:55:01', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:55:01', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=110', 0, 'property', '', 0),
(111, 1, '2023-02-19 19:55:51', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:55:51', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=111', 0, 'property', '', 0),
(112, 1, '2023-02-19 19:56:58', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:56:58', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=112', 0, 'property', '', 0),
(113, 1, '2023-02-19 19:58:14', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:58:14', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=113', 0, 'property', '', 0),
(114, 1, '2023-02-19 19:58:29', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:58:29', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=114', 0, 'property', '', 0),
(115, 1, '2023-02-19 19:59:39', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 19:59:39', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=115', 0, 'property', '', 0),
(116, 1, '2023-02-19 20:01:09', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:01:09', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=116', 0, 'property', '', 0),
(117, 1, '2023-02-19 20:01:30', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:01:30', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=117', 0, 'property', '', 0),
(118, 1, '2023-02-19 20:04:52', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:04:52', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=118', 0, 'property', '', 0),
(119, 1, '2023-02-19 20:05:37', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:05:37', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=119', 0, 'property', '', 0),
(120, 1, '2023-02-19 20:07:53', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:07:53', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=120', 0, 'property', '', 0),
(121, 1, '2023-02-19 20:08:28', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:08:28', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=121', 0, 'property', '', 0),
(122, 1, '2023-02-19 20:08:37', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:08:37', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=122', 0, 'property', '', 0),
(123, 1, '2023-02-19 20:09:04', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:09:04', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=123', 0, 'property', '', 0),
(124, 1, '2023-02-19 20:18:30', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:18:30', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=124', 0, 'property', '', 0),
(125, 1, '2023-02-19 20:18:39', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-02-19 20:18:39', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?p=125', 0, 'post', '', 0) ;
INSERT INTO `re_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(126, 1, '2023-02-19 20:18:54', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:18:54', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=126', 0, 'property', '', 0),
(127, 1, '2023-02-19 20:19:03', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:19:03', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=127', 0, 'property', '', 0),
(128, 1, '2023-02-19 20:20:05', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:20:05', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=128', 0, 'property', '', 0),
(129, 1, '2023-02-19 20:22:05', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:22:05', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=129', 0, 'property', '', 0),
(130, 1, '2023-02-19 20:22:58', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:22:58', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=130', 0, 'property', '', 0),
(131, 1, '2023-02-19 20:25:19', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:25:19', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=131', 0, 'property', '', 0),
(132, 1, '2023-02-19 20:26:06', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 20:26:06', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=132', 0, 'property', '', 0),
(133, 1, '2023-02-19 23:26:12', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:26:12', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=133', 0, 'property', '', 0),
(134, 1, '2023-02-19 23:27:05', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:27:05', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=134', 0, 'property', '', 0),
(135, 1, '2023-02-19 23:27:29', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:27:29', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=135', 0, 'property', '', 0) ;
INSERT INTO `re_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(136, 1, '2023-02-19 23:27:41', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:27:41', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=136', 0, 'property', '', 0),
(137, 1, '2023-02-19 23:43:45', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:43:45', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=137', 0, 'property', '', 0),
(138, 1, '2023-02-19 23:50:40', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:50:40', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=138', 0, 'property', '', 0),
(139, 1, '2023-02-19 23:51:04', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:51:04', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=139', 0, 'property', '', 0),
(140, 1, '2023-02-19 23:51:34', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:51:34', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=140', 0, 'property', '', 0),
(141, 1, '2023-02-19 23:52:07', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:52:07', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=141', 0, 'property', '', 0),
(142, 1, '2023-02-19 23:52:16', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:52:16', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=142', 0, 'property', '', 0),
(143, 1, '2023-02-19 23:52:41', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-19 23:52:41', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=143', 0, 'property', '', 0),
(144, 1, '2023-02-20 18:14:30', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:14:30', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=144', 0, 'property', '', 0),
(145, 1, '2023-02-20 18:16:18', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:16:18', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=145', 0, 'property', '', 0),
(146, 1, '2023-02-20 18:17:22', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:17:22', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=146', 0, 'property', '', 0),
(147, 1, '2023-02-20 18:17:49', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:17:49', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=147', 0, 'property', '', 0),
(148, 1, '2023-02-20 18:18:52', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:18:52', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=148', 0, 'property', '', 0),
(149, 1, '2023-02-20 18:19:00', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:19:00', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=149', 0, 'property', '', 0),
(150, 1, '2023-02-20 18:19:53', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:19:53', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=150', 0, 'property', '', 0),
(151, 1, '2023-02-20 18:21:33', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:21:33', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=151', 0, 'property', '', 0),
(152, 1, '2023-02-20 18:21:45', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:21:45', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=152', 0, 'property', '', 0),
(153, 1, '2023-02-20 18:23:12', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:23:12', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=153', 0, 'property', '', 0),
(154, 1, '2023-02-20 18:24:54', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:24:54', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=154', 0, 'property', '', 0),
(155, 1, '2023-02-20 18:27:30', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:27:30', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=155', 0, 'property', '', 0),
(156, 1, '2023-02-20 18:28:05', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:28:05', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=156', 0, 'property', '', 0),
(157, 1, '2023-02-20 18:29:07', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:29:07', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=157', 0, 'property', '', 0),
(158, 1, '2023-02-20 18:29:20', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:29:20', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=158', 0, 'property', '', 0),
(159, 1, '2023-02-20 18:31:36', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:31:36', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=159', 0, 'property', '', 0),
(160, 1, '2023-02-20 18:32:27', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:32:27', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=160', 0, 'property', '', 0),
(161, 1, '2023-02-20 18:36:28', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:36:28', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=161', 0, 'property', '', 0),
(162, 1, '2023-02-20 18:36:51', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:36:51', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=162', 0, 'property', '', 0),
(163, 1, '2023-02-20 18:38:32', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:38:32', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=163', 0, 'property', '', 0),
(164, 1, '2023-02-20 18:39:13', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:39:13', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=164', 0, 'property', '', 0),
(165, 1, '2023-02-20 18:40:45', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-02-20 18:40:45', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?p=165', 0, 'post', '', 0),
(166, 1, '2023-02-20 18:42:41', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:42:41', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=166', 0, 'property', '', 0),
(167, 1, '2023-02-20 18:44:13', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:44:13', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=167', 0, 'property', '', 0),
(168, 1, '2023-02-20 18:53:52', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:53:52', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=168', 0, 'property', '', 0),
(169, 1, '2023-02-20 18:58:52', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 18:58:52', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=169', 0, 'property', '', 0),
(170, 1, '2023-02-20 19:01:36', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 19:01:36', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=170', 0, 'property', '', 0),
(171, 1, '2023-02-20 19:01:52', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 19:01:52', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=171', 0, 'property', '', 0),
(172, 1, '2023-02-20 19:02:08', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 19:02:08', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?page_id=172', 0, 'page', '', 0),
(173, 1, '2023-02-20 19:03:24', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-02-20 19:03:24', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?p=173', 0, 'post', '', 0),
(174, 1, '2023-02-20 19:03:44', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 19:03:44', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=174', 0, 'property', '', 0),
(175, 1, '2023-02-20 19:04:27', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 19:04:27', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=175', 0, 'property', '', 0),
(176, 1, '2023-02-20 19:28:09', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 19:28:09', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=176', 0, 'property', '', 0),
(177, 1, '2023-02-20 19:28:50', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 19:28:50', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=177', 0, 'property', '', 0),
(178, 1, '2023-02-20 19:47:36', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-20 19:47:36', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=178', 0, 'property', '', 0),
(179, 1, '2023-02-21 22:44:50', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 22:44:50', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=179', 0, 'property', '', 0),
(180, 1, '2023-02-21 22:48:41', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 22:48:41', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=180', 0, 'property', '', 0),
(181, 1, '2023-02-21 22:54:02', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 22:54:02', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=181', 0, 'property', '', 0),
(182, 1, '2023-02-21 22:54:37', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 22:54:37', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=182', 0, 'property', '', 0),
(183, 1, '2023-02-21 22:54:49', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 22:54:49', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=183', 0, 'property', '', 0),
(184, 1, '2023-02-21 22:55:15', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 22:55:15', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=184', 0, 'property', '', 0),
(185, 1, '2023-02-21 22:57:34', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 22:57:34', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=185', 0, 'property', '', 0),
(186, 1, '2023-02-21 23:06:34', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 23:06:34', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=186', 0, 'property', '', 0),
(187, 1, '2023-02-21 23:21:06', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 23:21:06', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=187', 0, 'property', '', 0),
(188, 1, '2023-02-21 23:21:23', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 23:21:23', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=188', 0, 'property', '', 0),
(189, 1, '2023-02-21 23:23:17', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 23:23:17', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=189', 0, 'property', '', 0),
(190, 1, '2023-02-21 23:23:41', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 23:23:41', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=190', 0, 'property', '', 0),
(191, 1, '2023-02-21 23:44:30', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 23:44:30', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=191', 0, 'property', '', 0),
(192, 1, '2023-02-21 23:46:26', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 23:46:26', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=192', 0, 'property', '', 0),
(193, 1, '2023-02-21 23:46:44', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-21 23:46:44', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=193', 0, 'property', '', 0),
(194, 1, '2023-02-22 00:19:23', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 00:19:23', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=194', 0, 'property', '', 0),
(195, 1, '2023-02-22 00:29:04', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 00:29:04', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=195', 0, 'property', '', 0),
(196, 1, '2023-02-22 00:33:04', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 00:33:04', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=196', 0, 'property', '', 0),
(197, 1, '2023-02-22 00:33:48', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 00:33:48', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=197', 0, 'property', '', 0),
(198, 1, '2023-02-22 01:00:47', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 01:00:47', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=198', 0, 'property', '', 0),
(199, 1, '2023-02-22 01:08:56', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 01:08:56', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=199', 0, 'property', '', 0),
(200, 1, '2023-02-22 01:18:04', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 01:18:04', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=200', 0, 'property', '', 0),
(201, 1, '2023-02-22 01:20:14', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 01:20:14', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?page_id=201', 0, 'page', '', 0),
(202, 1, '2023-02-22 14:41:12', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-02-22 14:41:12', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?post_type=property&p=202', 0, 'property', '', 0),
(203, 1, '2023-02-25 17:03:14', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-02-25 17:03:14', '0000-00-00 00:00:00', '', 0, 'http://real-estate.test/?p=203', 0, 'post', '', 0) ;

#
# Конец содержимого данных таблицы `re_posts`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_term_relationships`
#

DROP TABLE IF EXISTS `re_term_relationships`;


#
# Структура таблицы `re_term_relationships`
#

CREATE TABLE `re_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_term_relationships`
#
INSERT INTO `re_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 7, 0),
(1, 8, 0),
(1, 9, 0),
(3, 7, 0),
(6, 2, 0),
(7, 3, 0),
(12, 9, 0),
(12, 11, 0),
(16, 9, 0),
(16, 15, 0),
(19, 7, 0),
(21, 8, 0),
(21, 22, 0),
(25, 6, 0),
(35, 6, 0),
(36, 6, 0),
(37, 6, 0),
(38, 6, 0),
(39, 7, 0),
(39, 18, 0),
(51, 7, 0),
(53, 7, 0),
(55, 7, 0),
(58, 7, 0),
(60, 7, 0),
(62, 7, 0),
(64, 7, 0),
(65, 7, 0),
(68, 7, 0),
(70, 7, 0),
(71, 7, 0),
(71, 20, 0),
(72, 7, 0),
(73, 10, 0),
(73, 19, 0),
(87, 10, 0),
(87, 18, 0),
(88, 14, 0),
(88, 18, 0),
(89, 7, 0),
(90, 14, 0),
(91, 14, 0),
(92, 7, 0),
(92, 19, 0),
(93, 14, 0),
(93, 19, 0),
(94, 6, 0),
(95, 14, 0),
(95, 20, 0),
(96, 10, 0),
(96, 20, 0),
(100, 10, 0),
(102, 7, 0),
(103, 7, 0),
(104, 7, 0),
(105, 7, 0),
(106, 7, 0),
(107, 7, 0),
(108, 7, 0),
(109, 7, 0),
(110, 7, 0),
(111, 7, 0),
(112, 7, 0),
(113, 7, 0),
(114, 7, 0),
(115, 7, 0),
(116, 7, 0),
(117, 7, 0),
(118, 7, 0),
(119, 7, 0),
(120, 7, 0),
(121, 7, 0),
(122, 7, 0),
(123, 7, 0),
(124, 7, 0),
(125, 7, 0),
(126, 7, 0),
(127, 7, 0),
(128, 7, 0),
(129, 7, 0),
(130, 7, 0),
(131, 7, 0),
(132, 7, 0),
(133, 7, 0),
(134, 7, 0),
(135, 7, 0),
(136, 7, 0),
(137, 7, 0),
(138, 7, 0),
(139, 7, 0),
(140, 7, 0),
(141, 7, 0),
(142, 7, 0),
(143, 7, 0),
(144, 7, 0),
(145, 7, 0),
(146, 7, 0),
(147, 7, 0),
(148, 7, 0) ;
INSERT INTO `re_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(149, 7, 0),
(150, 7, 0),
(151, 7, 0),
(152, 7, 0),
(153, 7, 0),
(154, 7, 0),
(155, 7, 0),
(156, 7, 0),
(157, 7, 0),
(158, 7, 0),
(159, 7, 0),
(160, 7, 0),
(161, 7, 0),
(162, 7, 0),
(163, 7, 0),
(164, 7, 0),
(165, 7, 0),
(166, 7, 0),
(167, 7, 0),
(168, 7, 0),
(169, 7, 0),
(170, 7, 0),
(171, 7, 0),
(172, 7, 0),
(173, 7, 0),
(174, 7, 0),
(175, 7, 0),
(176, 7, 0),
(177, 7, 0),
(178, 7, 0),
(179, 7, 0),
(180, 7, 0),
(181, 7, 0),
(182, 7, 0),
(183, 7, 0),
(184, 7, 0),
(185, 7, 0),
(186, 7, 0),
(187, 7, 0),
(188, 7, 0),
(189, 7, 0),
(190, 7, 0),
(191, 7, 0),
(192, 7, 0),
(193, 7, 0),
(194, 7, 0),
(195, 7, 0),
(196, 7, 0),
(197, 7, 0),
(198, 7, 0),
(199, 7, 0),
(200, 7, 0),
(201, 7, 0),
(202, 7, 0),
(203, 7, 0) ;

#
# Конец содержимого данных таблицы `re_term_relationships`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_term_taxonomy`
#

DROP TABLE IF EXISTS `re_term_taxonomy`;


#
# Структура таблицы `re_term_taxonomy`
#

CREATE TABLE `re_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_term_taxonomy`
#
INSERT INTO `re_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'wp_theme', '', 0, 1),
(6, 6, 'nav_menu', '', 0, 6),
(7, 7, 'language', 'a:3:{s:6:"locale";s:5:"en_US";s:3:"rtl";i:0;s:9:"flag_code";s:2:"us";}', 0, 15),
(8, 8, 'term_language', '', 0, 2),
(9, 9, 'term_translations', 'a:3:{s:2:"en";i:1;s:2:"ru";i:12;s:2:"uk";i:16;}', 0, 3),
(10, 10, 'language', 'a:3:{s:6:"locale";s:5:"ru_RU";s:3:"rtl";i:0;s:9:"flag_code";s:2:"ru";}', 0, 4),
(11, 11, 'term_language', '', 0, 1),
(12, 12, 'category', '', 0, 0),
(14, 14, 'language', 'a:3:{s:6:"locale";s:2:"uk";s:3:"rtl";i:0;s:9:"flag_code";s:2:"ua";}', 0, 3),
(15, 15, 'term_language', '', 0, 1),
(16, 16, 'category', '', 0, 0),
(18, 18, 'post_translations', 'a:3:{s:2:"en";i:39;s:2:"ru";i:87;s:2:"uk";i:88;}', 0, 3),
(19, 19, 'post_translations', 'a:3:{s:2:"en";i:92;s:2:"ru";i:73;s:2:"uk";i:93;}', 0, 3),
(20, 20, 'post_translations', 'a:3:{s:2:"uk";i:95;s:2:"en";i:71;s:2:"ru";i:96;}', 0, 3),
(21, 21, 'features', '', 0, 0),
(22, 22, 'term_translations', 'a:1:{s:2:"en";i:21;}', 0, 1) ;

#
# Конец содержимого данных таблицы `re_term_taxonomy`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_termmeta`
#

DROP TABLE IF EXISTS `re_termmeta`;


#
# Структура таблицы `re_termmeta`
#

CREATE TABLE `re_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_termmeta`
#
INSERT INTO `re_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 21, 'image', ''),
(2, 21, '_image', 'field_63eeafb069a76') ;

#
# Конец содержимого данных таблицы `re_termmeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_terms`
#

DROP TABLE IF EXISTS `re_terms`;


#
# Структура таблицы `re_terms`
#

CREATE TABLE `re_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_terms`
#
INSERT INTO `re_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'twentytwentythree', 'twentytwentythree', 0),
(3, 'twentytwentytwo', 'twentytwentytwo', 0),
(6, 'Main Menu', 'main-menu', 0),
(7, 'English', 'en', 0),
(8, 'English', 'pll_en', 0),
(9, 'pll_63f0c5f425c62', 'pll_63f0c5f425c62', 0),
(10, 'Русский', 'ru', 0),
(11, 'Русский', 'pll_ru', 0),
(12, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8-ru', 0),
(14, 'Українська', 'uk', 0),
(15, 'Українська', 'pll_uk', 0),
(16, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8-uk', 0),
(18, 'pll_63f0c6ce7a459', 'pll_63f0c6ce7a459', 0),
(19, 'pll_63f0cc52cccd1', 'pll_63f0cc52cccd1', 0),
(20, 'pll_63f0ebc7d5c8c', 'pll_63f0ebc7d5c8c', 0),
(21, 'test', 'test', 0),
(22, 'pll_63f5ff9cf4123', 'pll_63f5ff9cf4123', 0) ;

#
# Конец содержимого данных таблицы `re_terms`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_usermeta`
#

DROP TABLE IF EXISTS `re_usermeta`;


#
# Структура таблицы `re_usermeta`
#

CREATE TABLE `re_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_usermeta`
#
INSERT INTO `re_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Elena'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 're_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 're_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(17, 1, 're_dashboard_quick_press_last_post_id', '203'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 're_persisted_preferences', 'a:4:{s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:0;s:12:"welcomeGuide";b:0;s:10:"openPanels";a:4:{i:0;s:16:"discussion-panel";i:1;s:14:"featured-image";i:2;s:11:"post-status";i:3;s:15:"page-attributes";}}s:9:"_modified";s:24:"2023-02-16T20:35:41.464Z";s:14:"core/edit-site";a:1:{s:12:"welcomeGuide";b:0;}s:17:"core/edit-widgets";a:2:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;}}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(22, 1, 'nav_menu_recently_edited', '6'),
(23, 1, 're_user-settings', 'mfold=o&editor=tinymce&libraryContent=browse&posts_list_mode=excerpt'),
(24, 1, 're_user-settings-time', '1677015921'),
(26, 1, 'session_tokens', 'a:1:{s:64:"a1380c1cde4ab8ebe36b2452a06706d289068dd29df53f658c2f3544432ba865";a:4:{s:10:"expiration";i:1677506588;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36";s:5:"login";i:1677333788;}}'),
(27, 1, 'enable_custom_fields', '1'),
(28, 1, 'closedpostboxes_property', 'a:2:{i:0;s:6:"ml_box";i:1;s:18:"tagsdiv-properties";}'),
(29, 1, 'metaboxhidden_property', 'a:1:{i:0;s:7:"slugdiv";}'),
(30, 1, 'meta-box-order_property', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:43:"ml_box,submitdiv,tagsdiv-features,citiesdiv";s:6:"normal";s:74:"tagsdiv-properies,acf-group_63ee9a161ea76,postimagediv,postexcerpt,slugdiv";s:8:"advanced";s:0:"";}'),
(31, 1, 'screen_layout_property', '2'),
(32, 1, 'edit_property_per_page', '20') ;

#
# Конец содержимого данных таблицы `re_usermeta`
# --------------------------------------------------------



#
# Удалить любую существующую таблицу `re_users`
#

DROP TABLE IF EXISTS `re_users`;


#
# Структура таблицы `re_users`
#

CREATE TABLE `re_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Содержимое данных таблицы `re_users`
#
INSERT INTO `re_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Elen', '$P$BjC6MrEfXTdtThAn5a32Zu3KZiuDFu/', 'elen', 'elenadreganova1982@gmail.com', 'http://real-estate.test', '2023-02-10 17:12:49', '', 0, 'Elena') ;

#
# Конец содержимого данных таблицы `re_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

